README for GRB-94921_B.zip

Company Part Number: 170-94921 REV B

Date: Fri, 11 Jul 2025 16:52:43 GMT

NXP Semiconductors
6501 William Cannon Drive West
Austin, TX 78735-8598


All EQs are to be sent to the ENTIRE team listed below.

Contract Manufacturer 
=====================
Include Account Manager
(PO responsible from the CM that sent you the gerber package)

CAD Engineer
============
Company Contact     : Martin Villarreal
Work Phone          : 512-895-XXXX
Email               : martin.villarreal@nxp.com

CAD Manager
===========
Company Contact     : Ionut Manolescu
Work Phone          : ---
Email               : ionut.manolescu@nxp.com

Manufacturing Program Manager
=============================
Company Contact     : Jose Calderon
Work Phone          : +31000000000
Email               : jose.calderon@nxp.com

Product Engineer
================
Company Contact     : Adolfo Magana
Work Phone          : ---
Email               : adolfo.magana@nxp.com

Design Engineer
================
Company Contact     : Jose Antonio Quiroz
Work Phone          : 512-895-XXXX
Email               : Jose.Quiroz@nxp.com

Design for Manufacturing Engineer
=================================
Company Contact     : Rosalia Gonzalez
Work Phone          : +52(33) 3283-2100 x2267
Email               : HWCOEPCBSolutions@nxp.com
